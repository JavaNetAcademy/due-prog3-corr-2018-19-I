package service;

import java.util.ArrayList;
import java.util.List;

import jdbc.ResourceDaoJDBCImpl;
import model.BasicResource;
import model.ResourceDao;

public class ResourceServiceObjectImpl {
	
	ResourceDao dao = new ResourceDaoJDBCImpl();
	
	public String getResourceInfo(long id){
		
		List<String> infoList = dao.getResourceInfo(id);
		String resourceInfo = "";
		
		if(infoList.size() == 0) 
		{
			resourceInfo = "hiba �zenet";
		}
		else 
		{
			for(String info : infoList) {
				resourceInfo += "" + info + "\n";
			}
		}
		
		return resourceInfo;
	}
	
	public String createResourceFromMaterial(String name, long material, double materialQuantity, int lifetime) {
		String createMessage = "";
		boolean createWasSuccessful = dao.createResourceFromMaterial(name, material, materialQuantity, lifetime);
		if(createWasSuccessful) {
			createMessage += "Resource sikeresen l�trehozva";
		}else {
			createMessage += "Resource l�trehoz�sa sikertelen volt";
		}
		return createMessage;
	}
	
	public List<BasicResource> getAllResources(){
		List<BasicResource> resourceList = dao.getAllResources();
		if(resourceList.size() == 0){
			resourceList = new ArrayList<BasicResource>();
		}
		return resourceList;
	}
	
	public void useResource(long id) {
		dao.useResource(id);
	}


}
