package jdbc;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.sql.Connection;
import model.Resource;
import model.Material;
import model.BasicResource;
import model.ResourceDao;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class ResourceDaoJDBCImpl implements ResourceDao{

	private Connection con;

    public ResourceDaoJDBCImpl() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/hoe?useSSL=false", "hoe", "hoe");
        } catch (Exception e) {
            System.exit(100);
        }
    }
	
	public List<String> getResourceInfo(long id) {
		List<String> resourceInfoList = new ArrayList<String>();
		
		try {
			PreparedStatement ps = con.prepareStatement("SELECT resource.id, basicResource.name, material.materialID, sum(coalesce(material.quantity,0)), basicResource.lifetimeOfResource, resource.ownerId, resource.usability FROM resource JOIN basicResource JOIN material ON basicResource.materialtoCreate=material.resourceID and basicResource.id=resource.id WHERE basicResource.name=? GROUP BY resource.id, ownerid");
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                resourceInfoList.add(rs.getString(2));
                resourceInfoList.add(String.valueOf(rs.getLong(3)));
                resourceInfoList.add(String.valueOf(rs.getDouble(4)));
                resourceInfoList.add(String.valueOf(rs.getInt(5)));
                resourceInfoList.add(rs.getString(7));
            }
        } catch (SQLException e) {
        	e.printStackTrace();
        }
		
        return resourceInfoList;
	}

	public boolean createResourceFromMaterial(String name, long material, double materialQuantity, int lifetime) {
		boolean resourceReady = false;
		try {
			PreparedStatement ps = con.prepareStatement("INSERT INTO basicresource(name,materialToCreate,materialQuantityToCreate,lifetimeOfResource) VALUES(?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, name);
			ps.setLong(2, material);
			ps.setDouble(3, materialQuantity);
            ps.setInt(4, lifetime);
            
            if(ps.execute()) {
            	resourceReady = true;
            }
            
        } catch (SQLException e) {
        	e.getMessage();
        }
        return resourceReady;
	}
	
	public List<BasicResource> getAllResources(){
		List<BasicResource> resourceList = new ArrayList<BasicResource>();
		try{
			PreparedStatement ps = con.prepareStatement("select id, name, materialToCreate, materialQuantityToCreate, lifetimeOfResource from basicresource");
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				BasicResource resource = new BasicResource();
				resource.setId(rs.getLong(1));
				resource.setName(rs.getString(2));
				resource.setMaterialToCreate(rs.getLong(3));
				resource.setMaterialQuantityToCreate(rs.getDouble(4));
				resource.setLifetimeOfResource(rs.getInt(5));
                resourceList.add(resource);
            }
			
		}catch (SQLException e) {
        	e.getMessage();
        }
		return resourceList;
	}
	
	public void useResource(long id) {
		try {
			PreparedStatement ps = con.prepareStatement("update basicResource set basicResource.lifetimeOfResource=basicResource.lifetimeOfResource-1 where resource.id=?");
            ps.setLong(1, id);
            ps.executeUpdate();
            
        } catch (SQLException e) {e.printStackTrace();}
    }

}
