package web;
import java.util.List;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.BasicResource;
import service.ResourceServiceObjectImpl;

@WebServlet(name = "ResourceServlet", urlPatterns = { "/resources/index" })
public class ResourceServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ResourceServiceObjectImpl service = new ResourceServiceObjectImpl();
		String name = request.getParameter("name");
		long material = Long.parseLong(request.getParameter("material"));
		Double quantity = Double.parseDouble(request.getParameter("quantity"));
		Integer lifetime = Integer.parseInt(request.getParameter("lifetime"));
		String createMessage = service.createResourceFromMaterial(name, material, quantity, lifetime);
		System.out.println("<script type=\"text/javascript\">");
		System.out.println("alert('" + createMessage + "');");
		System.out.println("location='index.jsp';");
		System.out.println("</script>");
		doGet(request, response);
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<div class=\"table-title\"><h3>Eddig létrehozott resource lista:</h3></div>"
				+ "<table class=\"table-fill\"><thead><tr>");
		out.println("<tbody class=\"table-hover\">");
		
				ResourceServiceObjectImpl service = new ResourceServiceObjectImpl();
		List<BasicResource> resourceList = service.getAllResources();
		for(BasicResource resource : resourceList){
			out.println("<tr>");
				out.println(
						"<td class=\"text-left\">" + resource.getName() + "</td>" + 
						"<td class=\"text-left\">" + resource.getMaterialToCreate() + "</td>" +
						"<td class=\"text-left\">" + resource.getMaterialQuantityToCreate() + "</td>" +
						"<td class=\"text-left\">" + resource.getLifetimeOfResource() + "</td>");
						out.print("<input type=\"button\" value=\"Infó\" name="); out.print("\""+ resource.getId() + "\""); out.print("/>");
				out.println("</tr>");
		}
		out.println("</tbody></table>");
		out.println("<jsp:include page='create.jsp'>");
		out.close();
	}

}
