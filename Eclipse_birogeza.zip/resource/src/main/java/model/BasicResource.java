package model;



public class BasicResource {
	
	private long id;
	private String name;
	private long materialToCreate;
	private double materialQuantityToCreate;
    private int lifetimeOfResource;
    
	public int getLifetimeOfResource() {
		return lifetimeOfResource;
	}
	public void setLifetimeOfResource(int lifetimeOfResource) {
		this.lifetimeOfResource = lifetimeOfResource;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public long getMaterialToCreate() {
		return materialToCreate;
	}
	public void setMaterialToCreate(long materialToCreate) {
		this.materialToCreate = materialToCreate;
	}
	public double getMaterialQuantityToCreate() {
		return materialQuantityToCreate;
	}
	public void setMaterialQuantityToCreate(double materialQuantityToCreate) {
		this.materialQuantityToCreate = materialQuantityToCreate;
	}
    
}
