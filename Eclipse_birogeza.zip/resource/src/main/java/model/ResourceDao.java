package model;

import java.util.List;

public interface ResourceDao {
	
	public List<String> getResourceInfo(long id);
	public boolean createResourceFromMaterial(String name, long material, double materialQuantity, int lifetime);
	public void useResource(long id);
	public List<BasicResource> getAllResources();

}
