package model;

public class Resource extends BasicResource{
	
	private long id; //bigint-k�nt l�trehozva a MySQL-ben
    private long ownerId;
    
    public Resource(){
    	super();
    }

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(long ownerId) {
		this.ownerId = ownerId;
	}
    
}
