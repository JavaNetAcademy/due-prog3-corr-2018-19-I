package model;

public class Material {
	
	private long resourcePlaceID;
	private long materialId;
	private double quantity;
	
	
	public long getResourceID() {
		return resourcePlaceID;
	}
	public void setResourceID(long resourceID) {
		this.resourcePlaceID = resourceID;
	}
	public long getMaterialId() {
		return materialId;
	}
	public void setMaterialId(long materialId) {
		this.materialId = materialId;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	
	

}
